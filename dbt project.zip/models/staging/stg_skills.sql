{{ config(
    tags=['basic', 'staging'],
    materialized='table'
) }}

WITH

skills_data AS (

    SELECT
        *
    FROM {{ source('employee', 'skills') }}

)

select *
from skills_data