import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, useParams } from 'react-router-dom';

function CreateEvent() {
  const [events, setEvents] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [registeredEvents, setRegisteredEvents] = useState([]);
  const [likedEvents, setLikedEvents] = useState([]);
  const { userId } = useParams();

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const response = await axios.get('http://localhost:5000/displayevents');
        setEvents(response.data);
      } catch (error) {
        console.error('Error fetching events:', error);
      }
    };

    const fetchCurrentUser = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/currentuser/${userId}`);
        setCurrentUser(response.data);
      } catch (error) {
        console.error('Error fetching current user:', error);
      }
    };

    fetchEvents();
    fetchCurrentUser();
    
  }, [userId]);

  const fetchRegisteredEvents = async () => {
      try {
          const response = await axios.get(`http://localhost:5000/registeredevents/${userId}/display`);
        setRegisteredEvents(response.data);
      } catch (error) {
        console.error('Error fetching registered events:', error);
      }
  };

  const fetchLikedEvents = async () => {
      try {
          const response = await axios.get(`http://localhost:5000/likedevents/${userId}/display`);
        setLikedEvents(response.data);
      } catch (error) {
        console.error('Error fetching liked events:', error);
      }
  };
  
  const handleAccept = async (eventId, title) => {
    if (isEventRegistered(eventId)) {
      alert('Already registered for this event');
      console.log('Already registered for this event');
      return;
    }
    try {
      const response = await axios.post(`http://localhost:5000/acceptevent/${eventId}`, {
        userId: userId,
      });
      if (response.status === 200) {
        alert('Event accepted successfully');
      } else {
        console.log('Acceptance failed');
      }
      fetchRegisteredEvents();
    }
    catch (error) {
      alert("Event aldready reg")
      console.error('Error accepting event:', error);
    }
  };

  const handleLike = async (eventId, title) => {
    const event_ids = likedEvents.map(event => event.eventId._id);
    if (event_ids.includes(eventId)) {
      const response = await axios.post(`http://localhost:5000/deletelikeevent/${eventId}`, {
          userId: userId,
        });
      // alert('Already liked this event');
      console.log('Already liked this event');
      return;
    } else {
      try {
        const response = await axios.post(`http://localhost:5000/likeevent/${eventId}`, {
          userId: userId,
        });
        if (response.status === 200) {
          alert('Event liked successfully');
        } else {
          console.log('like failed');
        }
        fetchLikedEvents();
      }
      catch (error) {
        alert("Event aldready liked")
        console.error('Error liking event:', error);
      }
    }
  };

  const isEventRegistered = (eventId) => {
    return registeredEvents.includes(eventId);
  };

  useEffect(() => {
    fetchRegisteredEvents();
  }, [registeredEvents])
  // useEffect(() => {
  //   console.log(registeredEvents);
  // }, [registeredEvents]);

  useEffect(() => {
    fetchLikedEvents();
  }, [likedEvents])
  // useEffect(() => {
  //   console.log(likedEvents);
  // }, [likedEvents]);

  return (
    <div className="App">
      <header className="App-header">
        <h1 style={{ margin: '0 auto' }}>Register Event</h1>
        <div className="header-buttons">
        <Link to={`/registerevent/${userId}/display`}>
          <button>View registered events</button>
        </Link>
        <Link to={`/likedevents/${userId}/display`}>
          <button>View liked events</button>
        </Link>
        </div>
      </header>
      
      <div className="events-list">
        {events.map((event, index) => (
          <div key={index} className="event-card">
            <h3>{event.title}</h3>
            <p><strong>Domain:</strong> {event.domain}</p>
            <p><strong>Date:</strong> {event.date}</p>
            <p><strong>Duration:</strong> {event.duration}</p>
            <p><strong>Trainer Name:</strong> {event.trainerName}</p>
            <p><strong>Location:</strong> {event.location}</p>
            <p><strong>Description:</strong> {event.desc}</p>
            <p><strong>Capacity:</strong>{event.currentcapacity} of {event.capacity}</p>
            
            <button 
              onClick={() => {
                console.log(registeredEvents.map(item => item.eventId._id));
                handleAccept(event._id, event.title);
              }}
              disabled={ registeredEvents.length > 0 && registeredEvents.map(item => item.eventId?._id).includes(event._id) }
            >
              { registeredEvents.length > 0 && registeredEvents.map(item => item.eventId?._id).includes(event._id) ? 'Accepted' : 'Accept'}
              {/* Accepted */}
            </button>
            <button onClick={() => {
              handleLike(event._id, event.title);
            }}>
              { likedEvents.length > 0 && likedEvents.map(item => item.eventId?._id).includes(event._id) ? 'Liked' : 'Like'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default CreateEvent;