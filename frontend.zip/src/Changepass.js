import React, {useState} from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';

const Changepass = () => {
    const emailID = new URLSearchParams(useLocation().search).get('emailID');
    const [password, setPassword] = useState("");

    const handleSubmit = () => {
        axios.post('http://localhost:5000/update', {emailID, newpassword: password})
            .then((res) => {
                if(res.status === 200) alert('Updated Password');
            })
            .catch(err => {
                console.log(err);
            })
    }

  return (
    <div>
        <header className="App-header">
        <h1>Change Password</h1>
      </header>
      <div className="change-password-container">
      <form className="login-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            name="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            required
          />
        </div>
        <div className="change-password-buttons">
        <button type="submit">Change Password</button>
        </div>
      </form>
      </div>
    </div>
  )
}

export default Changepass