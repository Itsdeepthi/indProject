const mongoose = require('mongoose');

const trainingEventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
    email: {
      type: String
  }
});

const TrainingEvent = mongoose.model('TrainingEvent', trainingEventSchema);

module.exports = TrainingEvent;