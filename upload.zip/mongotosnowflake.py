import csv
from pymongo import MongoClient
import snowflake.connector

# MongoDB Connection
client = MongoClient("mongodb+srv://Deeps:4b720aCgigLtxsst@cluster0.xdxmah3.mongodb.net/")
db = client["Cluster0"]

# Snowflake Connection
conn = snowflake.connector.connect(
    user='itsdeepthi',
    password='Jman@600113',
    account='ifisswo-uo57070',
    warehouse='COMPUTE_WH',
    database='EMPLOYEE_LEARNING',
    schema='PUBLIC'
)

def upload_data_to_snowflake(collection_name):
    # Fetch data from MongoDB
    cursor = db[collection_name].find({})
    data = [row for row in cursor]

    # Prepare CSV file path
    csv_file_path = f"{collection_name}.csv"

    # Write data to CSV file
    with open(csv_file_path, 'w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=data[0].keys())
        writer.writeheader()
        for row in data:
            writer.writerow(row)

    # Upload CSV file to Snowflake
    cur = conn.cursor()
    cur.execute(f"PUT file://{csv_file_path} @~")
    cur.execute(f"COPY INTO {collection_name}")
    cur.close()

def upload_collections_to_snowflake():
    collections = ["likes", "skills", "trainingevents", "userregisters", "users"]
    for collection in collections:
        upload_data_to_snowflake(collection)

if __name__ == "__main__":
    upload_collections_to_snowflake()
